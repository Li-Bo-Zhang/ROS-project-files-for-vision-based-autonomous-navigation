from util import *
import torchvision
# from base import BaseModel
from utils.helpers import *

from utils import *

class Resnet(nn.Module):
    def __init__(self, in_channels, backbone, out_channels_gcn=(85, 128),
                 pretrained=True, kernel_sizes=(5, 7)):
        super(Resnet, self).__init__()
        resnet = getattr(torchvision.models, backbone)(pretrained)

        if in_channels == 3:
            conv1 = resnet.conv1
        else:
            conv1 = nn.Conv2d(in_channels, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.initial = nn.Sequential(
            conv1,
            resnet.bn1,
            resnet.relu,
            resnet.maxpool)

        self.layer1 = resnet.layer1
        self.layer2 = resnet.layer2
        self.layer3 = resnet.layer3
        self.layer4 = resnet.layer4
        if not pretrained: initialize_weights(self)

    def forward(self, x):
        x = self.initial(x)
        conv1_sz = (x.size(2), x.size(3))
        x1 = self.layer1(x)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)
        return x1, x2, x3, x4, conv1_sz


class PCNet(nn.Module):  # (2 , 2, 6, 2)
    def __init__(self, n_classes, kernel_sieze, in_channels=3, pretrained=True, backbone='resnet152', dilation=2, freeze_backbone=False):
        super(PCNet, self).__init__()

        self.backbone = Resnet(in_channels, pretrained=pretrained, backbone=backbone)

        self.bottleneck1 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=dilation,
                                      p_drop=0.1)
        self.unsample1 = UnsampleBilinear(scale_factor=2)
        self.bottleneck2 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=256, dilation=dilation,
                                      p_drop=0.1)
        self.bottleneck3 = Block_GCN1(kernel_size=kernel_sieze, in_channels=1024, out_channels=256, dilation=dilation,
                                      p_drop=0.1)
        self.bottleneck4 = Block_GCN1(kernel_size=kernel_sieze, in_channels=2048, out_channels=256, dilation=dilation,
                                      p_drop=0.1)
        self.conv = Conv_1x1(in_channels=256, out_channels=n_classes)
        self.unsample2 = UnsampleBilinear(scale_factor=4)

        if freeze_backbone:
            set_trainable([self.backbone], False)

    def forward(self, x):
        x1, x2, x3, x4, conv1_sz = self.backbone(x)

        x1 = self.bottleneck1(x1)
        x2 = self.bottleneck2(x2)
        x3 = self.bottleneck3(x3)
        x4 = self.bottleneck4(x4)

        # import ipdb
        # ipdb.set_trace()

        x4 = self.unsample1(x4)
        x3 = x4 + x3
        x3 = self.unsample1(x3)
        x2 = x3 + x2
        x2 = self.unsample1(x2)
        x1 = x1 + x2
        x = self.unsample2(x1)
        x = self.conv(x)

        return x


class GCNet(nn.Module):  # (2 , 2, 6, 2)
    def __init__(self, n_classes, kernel_sieze=3, att=None):
        super(GCNet, self).__init__()

        # stage 1
        self.bottleneck10 = BR_Block(in_channels=3, out_channels=16)
        self.bottleneck11 = Block_GCN1(kernel_size=kernel_sieze, in_channels=16, out_channels=16, dilation=2,
                                       p_drop=0.1)
        self.bottleneck12 = Block_GCN1(kernel_size=kernel_sieze, in_channels=16, out_channels=16, dilation=2,
                                       p_drop=0.1)
        self.conv1 = Conv_1x1(in_channels=16, out_channels=16)
        self.unsample1 = Unsample(in_channels=16, out_channels=16)

        # stage 2
        self.bottleneck20 = BR_Block(16, 64)
        self.bottleneck21 = Block_GCN1(kernel_size=kernel_sieze, in_channels=64, out_channels=64, dilation=2,
                                       p_drop=0.1)
        self.bottleneck22 = Block_GCN1(kernel_size=kernel_sieze, in_channels=64, out_channels=64, dilation=2,
                                       p_drop=0.1)
        self.conv2 = Conv_1x1(in_channels=64, out_channels=64)
        self.unsample2 = Unsample(in_channels=64, out_channels=16)

        # stage 3
        self.bottleneck30 = BR_Block(64, 128)
        self.bottleneck31 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck32 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck33 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck34 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck35 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck36 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.conv3 = Conv_1x1(in_channels=128, out_channels=128)
        self.unsample3 = Unsample(in_channels=128, out_channels=64)

        # stage 4
        self.bottleneck40 = BR_Block(128, 256)
        self.bottleneck41 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=2,
                                       p_drop=0.1)
        self.bottleneck42 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=2,
                                       p_drop=0.1)
        self.conv4 = Conv_1x1(in_channels=256, out_channels=256)
        self.unsample4 = Unsample(in_channels=256, out_channels=128)

        self.outconv = Outconv(in_channel=16, out_channel=n_classes)

        self.att = att
        if att:
            self.attention1 = cbam_block(16)
            self.attention2 = cbam_block(64)
            self.attention3 = cbam_block(128)
            self.attention4 = cbam_block(256)

    def forward(self, x):
        # stage 1
        x = self.bottleneck10(x)
        x = self.bottleneck11(x)
        x = self.bottleneck12(x)
        if self.att:
            x1 = self.attention1(x)
            x1 = self.conv1(x1)
        else:
            x1 = self.conv1(x)

        # stage 2
        x = self.bottleneck20(x)
        x = self.bottleneck21(x)
        x = self.bottleneck22(x)
        if self.att:
            x2 = self.attention2(x)
            x2 = self.conv2(x2)
        else:
            x2 = self.conv2(x)

        # stage 3
        x = self.bottleneck30(x)
        x = self.bottleneck31(x)
        x = self.bottleneck32(x)
        x = self.bottleneck33(x)
        x = self.bottleneck34(x)
        x = self.bottleneck35(x)
        x = self.bottleneck36(x)
        if self.att:
            x3 = self.attention3(x)
            x3 = self.conv3(x3)
        else:
            x3 = self.conv3(x)

        # stage 4
        x = self.bottleneck40(x)
        x = self.bottleneck41(x)
        x = self.bottleneck42(x)
        if self.att:
            x4 = self.attention4(x)
            x4 = self.conv4(x4)
        else:
            x4 = self.conv4(x)
        x4 = self.unsample4(x4)

        # import ipdb
        # ipdb.set_trace()

        x3 = x3 + x4
        x3 = self.unsample3(x3)

        x2 = x2 + x3
        x2 = self.unsample2(x2)

        x1 = x2 + x1
        x1 = self.unsample1(x1)
        x = self.outconv(x1)

        return x


class GCENet(nn.Module):  # (2 , 2, 6, 2)
    def __init__(self, n_classes, kernel_sieze=3):
        super(GCENet, self).__init__()

        self.bottleneck10 = BR_Block(in_channels=3, out_channels=16)
        self.bottleneck11 = BR_Block(in_channels=16, out_channels=64)
        self.bottleneck12 = BR_Block(in_channels=64, out_channels=128)

        self.bottleneck20 = BR_Block(128, 256)

        self.bottleneck21 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=1,
                                       p_drop=0.1)
        self.bottleneck22 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=2,
                                       p_drop=0.1)
        self.bottleneck23 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=5,
                                       p_drop=0.1)
        self.bottleneck24 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=3,
                                       p_drop=0.1)

        self.bottleneck31 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=1,
                                       p_drop=0.1)
        self.bottleneck32 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=1,
                                       p_drop=0.1)
        self.conv33 = Conv_1x1(in_channels=512, out_channels=256)

        self.bottleneck40 = BR_Block(256, 512)
        self.bottleneck41 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=1,
                                       p_drop=0.1)
        self.bottleneck42 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=2,
                                       p_drop=0.1)
        self.bottleneck43 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=5,
                                       p_drop=0.1)
        self.bottleneck44 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=3,
                                       p_drop=0.1)
        self.bottleneck45 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=1,
                                       p_drop=0.1)
        self.bottleneck46 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=2,
                                       p_drop=0.1)
        self.bottleneck47 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=5,
                                       p_drop=0.1)
        self.bottleneck48 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=3,
                                       p_drop=0.1)

        self.bottleneck51 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=512, dilation=1,
                                       p_drop=0.1)
        self.unsample52 = Unsample(in_channels=512, out_channels=256)

        self.bottleneck61 = Block_GCN1(kernel_size=kernel_sieze, in_channels=512, out_channels=256, dilation=1,
                                       p_drop=0.1)
        self.bottleneck62 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=1,
                                       p_drop=0.1)
        self.unsample63 = Unsample(in_channels=256, out_channels=128)

        self.bottleneck71 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=128, dilation=1,
                                       p_drop=0.1)
        self.bottleneck72 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=1,
                                       p_drop=0.1)
        self.unsample81 = UnsampleBilinear()
        self.conv82 = Conv_1x1(in_channels=128, out_channels=n_classes)

    def forward(self, x):
        # stage 1
        x = self.bottleneck10(x)
        x = self.bottleneck11(x)
        x1 = self.bottleneck12(x)

        x2 = self.bottleneck20(x1)

        # stage 2
        x = self.bottleneck20(x1)
        x = self.bottleneck21(x)
        x = self.bottleneck22(x)
        x = self.bottleneck23(x)
        x = self.bottleneck24(x)

        x3 = self.bottleneck31(x)

        x = self.bottleneck32(x3)

        x = torch.cat((x2, x), dim=1)
        x = self.conv33(x)

        x = self.bottleneck40(x)
        x = self.bottleneck41(x)
        x = self.bottleneck42(x)
        x = self.bottleneck43(x)
        x = self.bottleneck44(x)
        x = self.bottleneck45(x)
        x = self.bottleneck46(x)
        x = self.bottleneck47(x)
        x = self.bottleneck48(x)

        x = self.bottleneck51(x)
        x = self.unsample52(x)

        x = torch.cat((x, x3), dim=1)

        x = self.bottleneck61(x)
        x = self.bottleneck62(x)

        x = self.unsample63(x)
        x = torch.cat((x1, x), dim=1)

        x = self.bottleneck71(x)
        x = self.bottleneck72(x)

        x = self.unsample81(x)
        x = self.conv82(x)

        return x





class GCNet_T(nn.Module):  # (2 , 2, 6, 2)
    def __init__(self, n_classes, kernel_sieze=3, att=None):
        super(GCNet_T, self).__init__()

        # stage 1
        self.bottleneck10 = BR_Block(in_channels=kernel_sieze, out_channels=16)
        self.bottleneck11 = Block_GCN1(kernel_size=kernel_sieze, in_channels=16, out_channels=16, dilation=2,
                                       p_drop=0.1)
        self.bottleneck12 = Block_GCN1(kernel_size=kernel_sieze, in_channels=16, out_channels=16, dilation=2,
                                       p_drop=0.1)
        self.conv1 = Conv_1x1(in_channels=16, out_channels=16)
        self.unsample1 = Unsample(in_channels=16, out_channels=16)

        # stage 2
        self.bottleneck20 = BR_Block(16, 64)
        self.bottleneck21 = Block_GCN1(kernel_size=kernel_sieze, in_channels=64, out_channels=64, dilation=2,
                                       p_drop=0.1)
        self.bottleneck22 = Block_GCN1(kernel_size=kernel_sieze, in_channels=64, out_channels=64, dilation=2,
                                       p_drop=0.1)
        self.conv2 = Conv_1x1(in_channels=64, out_channels=64)
        self.unsample2 = Unsample(in_channels=64, out_channels=16)

        # stage 3
        self.bottleneck30 = BR_Block(64, 128)
        self.bottleneck31 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck32 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck33 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck34 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck35 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.bottleneck36 = Block_GCN1(kernel_size=kernel_sieze, in_channels=128, out_channels=128, dilation=2,
                                       p_drop=0.1)
        self.conv3 = Conv_1x1(in_channels=128, out_channels=128)
        self.unsample3 = Unsample(in_channels=128, out_channels=64)

        # stage 4
        self.bottleneck40 = BR_Block(128, 256)
        self.bottleneck41 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=2,
                                       p_drop=0.1)
        self.bottleneck42 = Block_GCN1(kernel_size=kernel_sieze, in_channels=256, out_channels=256, dilation=2,
                                       p_drop=0.1)
        self.conv4 = Conv_1x1(in_channels=256, out_channels=256)
        self.unsample4 = Unsample(in_channels=256, out_channels=128)

        self.outconv = Outconv(in_channel=16, out_channel=n_classes)

        self.att = att
        if att:
            self.attention1 = cbam_block(16)
            self.attention2 = cbam_block(64)
            self.attention3 = cbam_block(128)
            self.attention4 = cbam_block(256)

    def forward(self, x):
        # stage 1
        x = self.bottleneck10(x)
        x = self.bottleneck11(x)
        x = self.bottleneck12(x)
        if self.att:
            x1 = self.attention1(x)
            x1 = self.conv1(x1)
        else:
            x1 = self.conv1(x)

        # stage 2
        x = self.bottleneck20(x)
        x = self.bottleneck21(x)
        x = self.bottleneck22(x)
        if self.att:
            x2 = self.attention2(x)
            x2 = self.conv2(x2)
        else:
            x2 = self.conv2(x)

        # stage 3
        x = self.bottleneck30(x)
        x = self.bottleneck31(x)
        x = self.bottleneck32(x)
        x = self.bottleneck33(x)
        x = self.bottleneck34(x)
        x = self.bottleneck35(x)
        x = self.bottleneck36(x)
        if self.att:
            x3 = self.attention3(x)
            x3 = self.conv3(x3)
        else:
            x3 = self.conv3(x)

        # stage 4
        x = self.bottleneck40(x)
        x = self.bottleneck41(x)
        x = self.bottleneck42(x)
        if self.att:
            x4 = self.attention4(x)
            x4 = self.conv4(x4)
        else:
            x4 = self.conv4(x)
        x4 = self.unsample4(x4)

        # import ipdb
        # ipdb.set_trace()

        x3 = x3 + x4
        x3 = self.unsample3(x3)

        x2 = x2 + x3
        x2 = self.unsample2(x2)

        x1 = x2 + x1
        x1 = self.unsample1(x1)
        x = self.outconv(x1)

        return x