#!/usr/bin/env python  
# unified_controller.py

import rospy
from enum import Enum
import subprocess
import signal
import time
import math
import threading
from std_msgs.msg import Bool
from geometry_msgs.msg import Twist
import json

# 定义控制状态
class ControlState(Enum):
    STATE_1_LINE_FOLLOWER = 1
    STATE_2_SCOUT_CONTROLLER = 2
    STATE_3_LINE_FOLLOWER = 3
    STATE_4_SCOUT_CONTROLLER = 4
    STATE_5_LINE_FOLLOWER = 5
    STATE_6_SCOUT_CONTROLLER = 6
    STATE_7_LINE_FOLLOWER = 7

class UnifiedController:
    def __init__(self, target_distances, scout_action_sequences):
        # 7个状态的状态机序列
        self.states_sequence = [
            ControlState.STATE_1_LINE_FOLLOWER,
            ControlState.STATE_2_SCOUT_CONTROLLER,
            ControlState.STATE_3_LINE_FOLLOWER,
            ControlState.STATE_4_SCOUT_CONTROLLER,
            ControlState.STATE_5_LINE_FOLLOWER,
            ControlState.STATE_6_SCOUT_CONTROLLER,
            ControlState.STATE_7_LINE_FOLLOWER
        ]

        self.target_distances = target_distances
        assert len(self.states_sequence) == len(self.target_distances), "States and distances must match in length."

        scout_states = [state for state in self.states_sequence if "SCOUT_CONTROLLER" in state.name] 
        rospy.loginfo(f"Number of SCOUT_CONTROLLER states: {len(scout_states)}") 
        rospy.loginfo(f"Number of scout_action_sequences: {len(scout_action_sequences)}")

        assert len(scout_states) == len(scout_action_sequences), "SCOUT_CONTROLLER states must match action sequences."

        self.scout_action_sequences = scout_action_sequences
        self.current_state_index = 0
        self.current_state = self.states_sequence[self.current_state_index]

        # ROS订阅者和发布者
        rospy.Subscriber("/state_completed", Bool, self.state_completed_callback)
        self.cmd_vel_pub = rospy.Publisher("/cmd_vel", Twist, queue_size=1)

        self.start_position = None
        self.distance_traveled = 0.0

        self.lock = threading.Lock()

        # 进程管理
        self.current_process = None

        # 初始化 ROS 节点参数
        self.line_follower_script = rospy.get_param("~line_follower_script", "line_follower_node.py")
        self.scout_controller_script = rospy.get_param("~scout_controller_script", "scout_controller_node.py")
        self.package_name = rospy.get_param("~package_name", "your_package")  # 替换为你的ROS包名

        # 动作序列索引
        self.scout_sequence_index = 0

    def start_process(self, state):
        if self.current_process:
            self.stop_process()

        if "LINE_FOLLOWER" in state.name:
            rospy.loginfo(f"Starting LineFollower for {state.name}")
            # 获取当前状态的目标距离
            target_distance = self.target_distances[self.current_state_index]
            # 启动 LineFollower 节点，并传递 distance_threshold 参数
            self.current_process = subprocess.Popen([
                'rosrun', self.package_name, self.line_follower_script,
                f'_distance_threshold:={target_distance}'
            ])
        elif "SCOUT_CONTROLLER" in state.name:
            rospy.loginfo(f"Starting ScoutController for {state.name}")
            # 获取对应的动作序列
            if self.scout_sequence_index >= len(self.scout_action_sequences):
                rospy.logerr("Not enough scout_action_sequences provided.")
                return
            action_sequence = self.scout_action_sequences[self.scout_sequence_index]
            self.scout_sequence_index += 1
            #print(self.scout_sequence_index)

            # 将动作序列写入临时JSON文件，供 ScoutController 节点读取
            temp_action_file = f"/home/nvidia/indoor_ws/src/robot_control/temp/scout_action_{self.scout_sequence_index}.json"
            with open(temp_action_file, "w") as f:
                json.dump(action_sequence, f)

            # 启动 ScoutController 节点，并传递动作序列文件路径作为参数
            #self.current_process = subprocess.Popen([
            #    'rosrun', self.package_name, self.scout_controller_script,
            #    f'_action_sequence_file:={temp_action_file}'
            #])
            self.current_process = subprocess.Popen(['rosrun', self.package_name, self.scout_controller_script])
            #print(123456)
        else:
            rospy.logerr(f"Unknown state: {state.name}")

    def stop_process(self):
        if self.current_process:
            rospy.loginfo("Stopping current state machine process.")
            self.current_process.send_signal(signal.SIGINT)
            try:
                self.current_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                rospy.logwarn("Process did not terminate gracefully. Killing it.")
                self.current_process.kill()
            self.current_process = None

    def state_completed_callback(self, msg):
        if msg.data:
            #print(msg.data)
            rospy.loginfo(f"State {self.current_state.name} completed.")
            self.transition_to_next_state()

    def transition_to_next_state(self):
        with self.lock:
            self.stop_process()
            self.current_state_index += 1
            if self.current_state_index >= len(self.states_sequence):
                rospy.loginfo("All states completed. Stopping robot.")
                self.stop_robot()
                rospy.signal_shutdown("All states completed.")
                return

            self.current_state = self.states_sequence[self.current_state_index]
            self.start_position = None
            self.distance_traveled = 0.0

            rospy.loginfo(f"Transitioning to {self.current_state.name}.")
            self.start_process(self.current_state)

    def run(self):
        # 启动第一个状态
        self.start_process(self.current_state)
        rospy.spin()

    def stop_robot(self):
        twist = Twist()
        self.cmd_vel_pub.publish(twist)
        rospy.loginfo("Robot stopped.")

if __name__ == '__main__':
    try:
        rospy.init_node('unified_controller', anonymous=True)

        # 定义每个状态的目标行驶距离（仅适用于 LineFollower 状态）
        # 7个状态，对应 4 个 LineFollower 状态和 3 个 ScoutController 状态
        # LineFollower 状态设定行驶距离 0.5 米，ScoutController 状态设定0
        target_distances = [0.8, 0, 5.5, 0, 4.5, 0, 0.8]
        #target_distances = [0, 0, 0, 0, 0, 0, 0.8]

        # 定义每个 ScoutController 状态的动作序列
        # 共有3个ScoutController状态(2,4,6)，需要3组动作序列
        scout_action_sequences = [
            [
                {'action': 'MOVE_FORWARD', 'value': 2},
                {'action': 'TURN', 'value': 90},
                {'action': 'MOVE_FORWARD', 'value': 0}
            ],
            [
                {'action': 'MOVE_FORWARD', 'value': 0},
                {'action': 'TURN', 'value': 180},
                {'action': 'MOVE_FORWARD', 'value': 0}
            ],
            [
                {'action': 'MOVE_FORWARD', 'value': 1.4},
                {'action': 'TURN', 'value': -90},
                {'action': 'MOVE_FORWARD', 'value': 0}
            ]
        ]

        controller = UnifiedController(target_distances=target_distances, scout_action_sequences=scout_action_sequences)
        controller.run()
    except rospy.ROSInterruptException:
        rospy.loginfo("Shutting down UnifiedController node.")
    except Exception as e:
        rospy.logerr(f"Unexpected error: {str(e)}")
