#!/usr/bin/env python
import cv2
import torch
import numpy as np
from PIL import Image as PILImage
from torchvision import transforms
import os
import json
from model import GCNet_T  # 确保 model.py 存在

# 配置
video_path = "/home/nvidia/dapeng/4-27/4-27/output.avi"  # 修改为你的视频路径
weights_path = "/home/nvidia/indoor_ws/src/robot_control/models/save_weights/model_148.pth"
palette_path = "/home/nvidia/indoor_ws/src/robot_control/models/palette.json"
num_classes = 2

# 设置设备
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

# 加载调色板
assert os.path.exists(palette_path), f"palette {palette_path} not found."
with open(palette_path, "rb") as f:
    palette_dict = json.load(f)
    palette = []
    for v in palette_dict.values():
        palette += v

# 加载模型
model = GCNet_T(n_classes=num_classes).to(device)
weights = torch.load(weights_path, map_location=device)["model"]
weights = {k.replace("module.", ""): v for k, v in weights.items()}
model.load_state_dict(weights)
model.eval()

# 视频读取
cap = cv2.VideoCapture(video_path)

alpha = 0.5  # 平滑因子
prev_x, prev_y = None, None

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # 图像预处理
    frame = cv2.resize(frame, (720, 576))
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    pil_img = PILImage.fromarray(rgb)
    transform = transforms.Compose([
        transforms.Resize([368, 288]),
        transforms.ToTensor(),
        transforms.Normalize(mean=(0.485, 0.456, 0.406),
                             std=(0.229, 0.224, 0.225))
    ])
    input_tensor = transform(pil_img).unsqueeze(0).to(device)

    # 模型推理
    with torch.no_grad():
        output = model(input_tensor)
        prediction = output.argmax(1).squeeze(0).cpu().numpy().astype(np.uint8)

    # 掩码处理
    mask = PILImage.fromarray(prediction)
    mask = transforms.Resize([frame.shape[0], frame.shape[1]])(mask)
    mask.putpalette(palette)
    gray = mask.convert("L")
    binary = np.array(gray)
    _, binary_mask = cv2.threshold(binary, 1, 255, cv2.THRESH_BINARY)

    # 寻找轮廓
    contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if contours:
        contour = max(contours, key=cv2.contourArea)
        left_pts, right_pts = [], []
        for pt in contour:
            x, y = pt[0]
            if x < frame.shape[1] // 2:
                left_pts.append([x, y])
            else:
                right_pts.append([x, y])
        left_pts = np.array(left_pts)
        right_pts = np.array(right_pts)

        if len(left_pts) > 0:
            [vx, vy, lx, ly] = cv2.fitLine(left_pts, cv2.DIST_L2, 0, 0.01, 0.01)
            left_slope = vy / vx
            left_inter = ly - (left_slope * lx)
        else:
            left_slope = left_inter = None

        if len(right_pts) > 0:
            [vx, vy, rx, ry] = cv2.fitLine(right_pts, cv2.DIST_L2, 0, 0.01, 0.01)
            right_slope = vy / vx
            right_inter = ry - (right_slope * rx)
        else:
            right_slope = right_inter = None

        if left_slope is not None and right_slope is not None:
            # 求交点
            inter_x = (right_inter - left_inter) / (left_slope - right_slope)
            inter_y = left_slope * inter_x + left_inter

            if prev_x is not None:
                inter_x = alpha * prev_x + (1 - alpha) * inter_x
                inter_y = alpha * prev_y + (1 - alpha) * inter_y
            prev_x, prev_y = inter_x, inter_y

            # 画出交点和中线
            y_bottom = frame.shape[0]
            x_bottom_left = int((y_bottom - left_inter) / left_slope) if left_slope is not None else frame.shape[1] // 2
            x_bottom_right = int((y_bottom - right_inter) / right_slope) if right_slope is not None else frame.shape[1] // 2
            center_x = int((x_bottom_left + x_bottom_right) / 2)

            cv2.line(frame, (int(inter_x), int(inter_y)), (x_bottom_left, y_bottom), (0, 0, 255), 2)
            cv2.line(frame, (int(inter_x), int(inter_y)), (x_bottom_right, y_bottom), (0, 255, 0), 2)
            cv2.line(frame, (int(inter_x), int(inter_y)), (center_x, y_bottom), (255, 0, 0), 2)

    # 显示结果
    cv2.imshow("Video Segmentation", frame)
    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

