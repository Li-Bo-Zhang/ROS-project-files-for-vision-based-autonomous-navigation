import torch
import torch.nn as nn


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=8):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        # 利用1x1卷积代替全连接
        self.fc1 = nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class cbam_block(nn.Module):
    def __init__(self, channel, ratio=8, kernel_size=7):
        super(cbam_block, self).__init__()
        self.channelattention = ChannelAttention(channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x


class Unsample(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Unsample, self).__init__()
        self.deconv = nn.ConvTranspose2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, padding=1,
                                         output_padding=1, stride=2, bias=False)

    def forward(self, x):
        x = self.deconv(x)

        return x


class UnsampleBilinear(nn.Module):
    def __init__(self, scale_factor):
        super(UnsampleBilinear, self).__init__()
        self.deconv = nn.UpsamplingBilinear2d(scale_factor=scale_factor)
    def forward(self, x):
        x = self.deconv(x)

        return x


class Conv_1x1(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(Conv_1x1, self).__init__()
        self.conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x = self.conv(x)

        return x


class Outconv(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(Outconv, self).__init__()
        self.conv = nn.Conv2d(in_channel, out_channel, kernel_size=1)

    def forward(self, x):
        x = self.conv(x)
        return x


class BR_Block(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(BR_Block, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=in_channels, out_channels=out_channels - in_channels, kernel_size=3,
                               stride=2, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels - in_channels)
        self.relu1 = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv2d(in_channels=out_channels - in_channels, out_channels=out_channels - in_channels,
                               kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels - in_channels)
        self.relu2 = nn.ReLU(inplace=True)

        self.pool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.relu3 = nn.ReLU(inplace=True)

    def forward(self, x):
        x1 = self.conv1(x)
        x1 = self.relu1(x1)
        x1 = self.conv2(x1)

        x2 = self.pool(x)

        x = self.relu3(torch.concat((x1, x2), dim=1))

        return x


class Block_GCN1(nn.Module):
    def __init__(self, kernel_size, in_channels, out_channels, stride=1, dilation=1, proj_ratio=6, p_drop=0):  # k=6
        super(Block_GCN1, self).__init__()

        inter_channels = in_channels * proj_ratio

        self.conv00 = nn.Conv2d(in_channels=in_channels, out_channels=(inter_channels // 2), kernel_size=3, stride=1,
                                bias=False, padding=1)  # python的chu fa shi fu dian lei xing
        self.bn00 = nn.BatchNorm2d(inter_channels // 2)
        self.relu00 = nn.ReLU(inplace=True)

        self.conv11 = nn.Conv2d(inter_channels // 2, inter_channels // 2, bias=False, stride=stride,
                                kernel_size=(kernel_size, 1), padding=(kernel_size // 2, 0))
        self.bn11 = nn.BatchNorm2d(inter_channels // 2)
        self.relu11 = nn.ReLU(inplace=True)
        self.conv12 = nn.Conv2d(inter_channels // 2, inter_channels // 2, bias=False, stride=stride,
                                kernel_size=(1, kernel_size), padding=(0, kernel_size // 2))
        self.bn12 = nn.BatchNorm2d(inter_channels // 2)
        self.relu12 = nn.ReLU(inplace=True)

        self.conv21 = nn.Conv2d(inter_channels // 2, inter_channels // 2, bias=False, stride=stride,
                                kernel_size=(1, kernel_size), padding=(0, kernel_size // 2))
        self.bn21 = nn.BatchNorm2d(inter_channels // 2)
        self.relu21 = nn.ReLU(inplace=True)
        self.conv22 = nn.Conv2d(inter_channels // 2, inter_channels // 2, bias=False, stride=stride,
                                kernel_size=(kernel_size, 1), padding=(kernel_size // 2, 0))
        self.bn22 = nn.BatchNorm2d(inter_channels // 2)
        self.relu22 = nn.ReLU(inplace=True)

        self.conv31 = nn.Conv2d(inter_channels // 2, inter_channels // 2, bias=False, stride=stride,
                                kernel_size=3, dilation=dilation, padding=dilation, groups=inter_channels // 2)
        self.conv32 = nn.Conv2d(inter_channels // 2, inter_channels // 2, kernel_size=1, stride=stride, bias=False)
        self.bn32 = nn.BatchNorm2d(inter_channels // 2)

        self.conv41 = nn.Conv2d(inter_channels, out_channels, stride=1, kernel_size=3, padding=3 // 2)

        self.regularizer = nn.Dropout2d(p_drop)

    def forward(self, x):
        x = self.conv00(x)
        x = self.bn00(x)
        x = self.relu00(x)

        x1 = self.conv11(x)
        x1 = self.bn11(x1)
        x1 = self.relu11(x1)
        x1 = self.conv12(x1)
        x1 = self.bn12(x1)
        x1 = self.relu12(x1)

        x2 = self.conv21(x)
        x2 = self.bn21(x2)
        x2 = self.relu21(x2)
        x2 = self.conv22(x2)
        x2 = self.bn22(x2)
        x2 = self.relu22(x2)

        x3 = self.conv31(x)
        x3 = self.bn32(x3)
        x3 = self.regularizer(x3)

        x = x1 + x2
        x = torch.concat((x, x3), dim=1)

        x = self.conv41(x)

        return x


class Block_GCN2(nn.Module):
    def __init__(self, kernel_size, in_channels, out_channels, stride=1, dilation=1, proj_ratio=6, p_drop=None):  # k=6
        super(Block_GCN2, self).__init__()

        inter_channels = in_channels * proj_ratio

        self.conv00 = nn.Conv2d(in_channels, inter_channels / 2, stride=1, bias=False)
        self.bn00 = nn.BatchNorm2d(inter_channels / 2)
        self.relu00 = nn.ReLU(inplace=True)

        self.conv11 = nn.Conv2d(inter_channels / 2, inter_channels / 2, bias=False, stride=stride,
                                kernel_size=(kernel_size, 1), padding=(kernel_size // 2, 0))
        self.bn11 = nn.BatchNorm2d(inter_channels / 2)
        self.relu11 = nn.ReLU(inplace=True)
        self.conv12 = nn.Conv2d(inter_channels / 2, inter_channels / 2, bias=False, stride=stride,
                                kernel_size=(1, kernel_size), padding=(0, kernel_size // 2))
        self.bn12 = nn.BatchNorm2d(inter_channels / 2)
        self.relu12 = nn.ReLU(inplace=True)

        self.conv21 = nn.Conv2d(inter_channels / 2, inter_channels / 2, bias=False, stride=stride,
                                kernel_size=(1, kernel_size), padding=(0, kernel_size // 2))
        self.bn21 = nn.BatchNorm2d(inter_channels / 2)
        self.relu21 = nn.ReLU(inplace=True)
        self.conv22 = nn.Conv2d(inter_channels / 2, inter_channels / 2, bias=False, stride=stride,
                                kernel_size=(kernel_size, 1), padding=(kernel_size // 2, 0))
        self.bn22 = nn.BatchNorm2d(inter_channels / 2)
        self.relu22 = nn.ReLU(inplace=True)

        self.conv31 = nn.Conv2d(inter_channels / 2, inter_channels / 2, bias=False, stride=stride,
                                kernel_size=kernel_size, dilation=dilation, padding=dilation, groups=inter_channels)
        self.conv32 = nn.Conv2d(inter_channels / 2, inter_channels / 2, kernel_size=1, stride=stride, bias=False)
        self.bn32 = nn.BatchNorm2d(inter_channels / 2)

        self.conv41 = nn.Conv2d(inter_channels, out_channels, stride=1, kernel_size=3, padding=kernel_size // 2)

        self.regularizer = nn.Dropout2d(p_drop)

    def forword(self, x):
        x = self.conv00(x)
        x = self.bn00(x)
        x = self.relu00(x)

        x1 = self.conv11(x)
        x1 = self.bn11(x1)
        x1 = self.relu11(x1)
        x1 = self.conv12(x1)
        x1 = self.bn12(x1)
        x1 = self.relu12(x1)

        x2 = self.conv21(x1)
        x2 = self.bn21(x2)
        x2 = self.relu21(x2)
        x2 = self.conv22(x2)
        x2 = self.bn22(x2)
        x2 = self.relu22(x2)

        x3 = self.conv31(x)
        x3 = self.bn32(x3)
        x3 = self.regularizer(x3)

        x = torch.concat((x2, x3), dim=1)
        x = self.conv41(x)

        return x
