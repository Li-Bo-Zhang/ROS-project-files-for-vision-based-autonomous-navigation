#!/usr/bin/env python
# Optimized line_follower_node.py

import sys
import time
import json
import cv2
import torch
from torchvision import transforms
import numpy as np
from PIL import Image as PILImage
import argparse
import os
import rospy
from sensor_msgs.msg import Image, LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import cv_bridge
from std_msgs.msg import Bool
from cv_bridge import CvBridge
import threading
import math

script_dir = os.path.dirname(os.path.realpath(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)
from model import GCNet_T

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0
        self.prev_error = 0
        self.prev_time = time.time()

    def update(self, error):
        current_time = time.time()
        dt = current_time - self.prev_time
        if dt <= 0.0:
            dt = 1e-16
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt
        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        self.prev_error = error
        self.prev_time = current_time
        return output

previous_intersection_x = None
previous_intersection_y = None
alpha = 0.5

class LineFollower:
    def __init__(self):
        rospy.init_node('line_follower', anonymous=True)

        self.bridge = CvBridge()
        self.lock = threading.Lock()
        self.obstacle_detected = False

        self.num_classes = rospy.get_param("~num_classes", 2)
        self.weights_path = rospy.get_param("~weights_path")
        self.palette_path = rospy.get_param("~palette_path")
        self.target_speed = rospy.get_param("~target_speed", 0.1)
        self.distance_threshold = rospy.get_param("~distance_threshold", 1.0)

        assert os.path.exists(self.weights_path), f"weights {self.weights_path} not found."
        assert os.path.exists(self.palette_path), f"palette {self.palette_path} not found."

        with open(self.palette_path, "rb") as f:
            self.palette_dict = json.load(f)
            self.palette = []
            for v in self.palette_dict.values():
                self.palette += v

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        rospy.loginfo("Using {} device.".format(self.device))

        self.model = GCNet_T(n_classes=self.num_classes).to(self.device)
        weights_dict = torch.load(self.weights_path, map_location=self.device)['model']
        self.model.load_state_dict(self.remove_module_prefix(weights_dict))

        self.pid = PIDController(kp=0.002, ki=0.0, kd=0.001)
        self.current_twist = Twist()
        self.frame_count = 0
        self.start_time = time.time()

        self.initial_position = None
        self.distance_traveled = 0.0
        self.distance_reached = False

        self.cmd_vel_pub = rospy.Publisher("/smoother_cmd_vel", Twist, queue_size=1)
        self.completion_pub = rospy.Publisher("/state_completed", Bool, queue_size=1)

        rospy.Subscriber("/usb_cam/image_raw", Image, self.image_callback)
        rospy.Subscriber("/scan", LaserScan, self.laser_callback)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)

        rospy.wait_for_message("/usb_cam/image_raw", Image)
        rospy.wait_for_message("/scan", LaserScan)
        rospy.wait_for_message("/odom", Odometry)

    def remove_module_prefix(self, state_dict):
        return {key.replace("module.", ""): val for key, val in state_dict.items()}

    def time_synchronized(self):
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        return time.time()

    def odom_callback(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        current_pos = np.array([x, y])
        if self.initial_position is None:
            self.initial_position = current_pos
        else:
            self.distance_traveled = np.linalg.norm(current_pos - self.initial_position)
            if self.distance_traveled >= self.distance_threshold and not self.distance_reached:
                rospy.loginfo(f"Traveled {self.distance_traveled:.2f} m, reaching threshold.")
                self.distance_reached = True
                self.stop_robot()

    def image_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            frame = cv2.resize(frame, (720, 576))
            gray_img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            if np.mean(gray_img) < 20 or np.mean(gray_img) > 230:
                rospy.logwarn("Lighting abnormal. Stopping.")
                self.stop_robot()
                return
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            pil_img = PILImage.fromarray(np.uint8(frame))
            original_img = pil_img
            data_transform = transforms.Compose([
                transforms.Resize([368, 288]),
                transforms.ToTensor(),
                transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225))
            ])
            img = data_transform(original_img)
            img = torch.unsqueeze(img, dim=0).to(self.device)

            self.model.eval()
            with torch.no_grad():
                output = self.model(img)
                prediction = output.argmax(1).squeeze(0).cpu().numpy().astype(np.uint8)
                mask = PILImage.fromarray(prediction)
                resize = transforms.Resize([frame.shape[0], frame.shape[1]])
                mask = resize(mask)
                mask.putpalette(self.palette)
                gray = np.array(mask.convert("L"))
                _, binary_mask = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)
                contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                if not contours:
                    rospy.logwarn("No valid contour, stopping.")
                    self.stop_robot()
                    return

                contour = max(contours, key=cv2.contourArea)
                left_points, right_points = [], []
                for point in contour:
                    x, y = point[0]
                    if x < frame.shape[1] // 2:
                        left_points.append([x, y])
                    else:
                        right_points.append([x, y])

                left_slope = right_slope = None
                left_intercept = right_intercept = None

                if len(left_points) > 0:
                    [vx, vy, lx, ly] = cv2.fitLine(np.array(left_points), cv2.DIST_L2, 0, 0.01, 0.01)
                    left_slope = vy / vx
                    left_intercept = ly - left_slope * lx

                if len(right_points) > 0:
                    [vx, vy, rx, ry] = cv2.fitLine(np.array(right_points), cv2.DIST_L2, 0, 0.01, 0.01)
                    right_slope = vy / vx
                    right_intercept = ry - right_slope * rx

                width = frame.shape[1]
                height = frame.shape[0]
                y_bottom = height

                if left_slope is not None and right_slope is not None:
                    intersection_x = (right_intercept - left_intercept) / (left_slope - right_slope)
                elif left_slope is not None:
                    intersection_x = (y_bottom - left_intercept) / left_slope
                elif right_slope is not None:
                    intersection_x = (y_bottom - right_intercept) / right_slope
                else:
                    rospy.logwarn("No line fitted. Stopping.")
                    self.stop_robot()
                    return

                global previous_intersection_x, previous_intersection_y, alpha
                if previous_intersection_x is not None:
                    intersection_x = alpha * previous_intersection_x + (1 - alpha) * intersection_x
                previous_intersection_x = intersection_x

                err = intersection_x - width / 2
                angular_z = np.clip(self.pid.update(err), -0.5, 0.5)
                twist = Twist()
                if not self.distance_reached and not self.obstacle_detected:
                    twist.angular.z = -angular_z
                    twist.linear.x = self.target_speed
                with self.lock:
                    self.current_twist = twist

            self.frame_count += 1
            if time.time() - self.start_time > 10:
                fps = self.frame_count / (time.time() - self.start_time)
                rospy.loginfo(f"FPS: {fps:.2f}")
                self.start_time = time.time()
                self.frame_count = 0

        except Exception as e:
            rospy.logerr(f"Image error: {str(e)}")
            self.stop_robot()
            time.sleep(1)

    def laser_callback(self, msg):
        try:
            ranges = np.array(msg.ranges)
            front_angles = np.concatenate([ranges[0:15], ranges[-15:]])
            min_distance = np.min(front_angles[np.isfinite(front_angles)]) if np.any(np.isfinite(front_angles)) else float('inf')
            with self.lock:
                if min_distance <= 0.15:
                    if not self.obstacle_detected:
                        rospy.loginfo(f"Obstacle {min_distance:.2f}m. Stopping.")
                    self.obstacle_detected = True
                else:
                    if self.obstacle_detected:
                        rospy.loginfo("Obstacle cleared.")
                    self.obstacle_detected = False
        except Exception as e:
            rospy.logerr(f"Laser error: {str(e)}")
            self.stop_robot()
            time.sleep(1)

    def get_twist(self):
        with self.lock:
            return self.current_twist

    def stop_robot(self):
        with self.lock:
            self.current_twist = Twist()
        self.cmd_vel_pub.publish(self.current_twist)
        self.completion_pub.publish(Bool(data=True))

    def run(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            twist_line_follower = self.get_twist()
            self.cmd_vel_pub.publish(twist_line_follower)
            rate.sleep()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        follower = LineFollower()
        follower.run()
    except rospy.ROSInterruptException:
        pass

