#!/usr/bin/env python
# line_follower_node.py
import sys
import time
import json
import cv2
import torch
from torchvision import transforms
import numpy as np
from PIL import Image as PILImage
import argparse
import os
import rospy
from sensor_msgs.msg import Image, LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
import cv_bridge
from std_msgs.msg import Bool
from cv_bridge import CvBridge, CvBridgeError
import threading
import math

# 获取当前脚本所在的目录
script_dir = os.path.dirname(os.path.realpath(__file__))
# 将脚本目录添加到 sys.path
if script_dir not in sys.path:
    sys.path.append(script_dir)
from model import PCNet, GCNet_T  # 确保 model 模块可用

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'


# PID控制器类
class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0
        self.prev_error = 0
        self.prev_time = time.time()

    def update(self, error):
        current_time = time.time()
        dt = current_time - self.prev_time
        if dt <= 0.0:
            dt = 1e-16  # 避免除以零
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt

        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)

        self.prev_error = error
        self.prev_time = current_time

        return output


# 全局变量，用于平滑交点坐标的指数移动平均
previous_intersection_x = None
previous_intersection_y = None
alpha = 0.5  # 指数平滑因子


class LineFollower:
    def __init__(self):
        # 初始化 ROS 节点
        rospy.init_node('line_follower', anonymous=True)

        # 初始化锁、变量和工具
        self.bridge = CvBridge()
        self.lock = threading.Lock()
        self.obstacle_detected = False

        # 解析参数
        self.num_classes = rospy.get_param("~num_classes", 2)
        self.weights_path = rospy.get_param("~weights_path", "/home/nvidia/indoor_ws/src/robot_control/models/save_weights/model_148.pth")
        self.palette_path = rospy.get_param("~palette_path", "/home/nvidia/indoor_ws/src/robot_control/models/palette.json")
        self.target_speed = rospy.get_param("~target_speed", 0.1)
        self.distance_threshold = rospy.get_param("~distance_threshold", 1.0)  # 设置需要行驶的距离阈值（米）
        rospy.loginfo(f"LineFollower: Using distance_threshold = {self.distance_threshold} meters.")

        assert os.path.exists(self.weights_path), f"weights {self.weights_path} not found."
        assert os.path.exists(self.palette_path), f"palette {self.palette_path} not found."

        with open(self.palette_path, "rb") as f:
            self.palette_dict = json.load(f)
            self.palette = []
            for v in self.palette_dict.values():
                self.palette += v

        # 获取设备（CPU或GPU）
        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        rospy.loginfo("Using {} device.".format(self.device))

        # 创建模型并加载权重
        self.model = GCNet_T(n_classes=self.num_classes).to(self.device)
        weights_dict = torch.load(self.weights_path, map_location=self.device)['model']
        self.model.load_state_dict(self.remove_module_prefix(weights_dict))

        # 初始化PID控制器
        self.pid = PIDController(kp=0.002, ki=0.0, kd=0.001)

        # 初始化当前twist
        self.current_twist = Twist()

        # 用于统计帧率相关信息
        self.frame_count = 0
        self.start_time = time.time()

        # 里程计相关变量
        self.initial_position = None
        self.current_position = None
        self.distance_traveled = 0.0
        self.distance_reached = False

        # 发布者与订阅者
        self.cmd_vel_pub = rospy.Publisher("/smoother_cmd_vel", Twist, queue_size=1)
        self.completion_pub = rospy.Publisher("/state_completed", Bool, queue_size=1)  # 发布完成信号
        #rospy.Subscriber("/camera/color/image_raw", Image, self.image_callback)
        rospy.Subscriber("/usb_cam/image_raw", Image, self.image_callback)
        rospy.Subscriber("/scan", LaserScan, self.laser_callback)
        rospy.Subscriber("/odom", Odometry, self.odom_callback)

    def remove_module_prefix(self, state_dict):
        new_state_dict = {}
        for key, value in state_dict.items():
            new_key = key.replace("module.", "")
            new_state_dict[new_key] = value
        return new_state_dict

    def time_synchronized(self):
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        return time.time()

    def odom_callback(self, msg):
        # 从里程计消息中获取机器人当前位姿（x,y）
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        current_pos = np.array([x, y])

        if self.initial_position is None:
            # 初始化时记录初始位姿
            self.initial_position = current_pos
        else:
            # 计算与初始位置的欧式距离
            self.distance_traveled = np.linalg.norm(current_pos - self.initial_position)

            # 如果已达到目标距离且未处理过
            if self.distance_traveled >= self.distance_threshold and not self.distance_reached:
                rospy.loginfo(f"Traveled {self.distance_traveled:.2f} m, reaching threshold.")
                self.distance_reached = True
                self.stop_robot()  # 停止机器人并发布完成信号

    def image_callback(self, msg):
        try:
            # 记录单张图片开始处理时间
            start_inference_time = self.time_synchronized()
            # 将ROS图像消息转换为OpenCV图像格式
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            frame = cv2.resize(frame, (720, 576))
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            pil_img = PILImage.fromarray(np.uint8(frame))
            original_img = pil_img

            # 图像预处理及模型预测
            data_transform = transforms.Compose([
                transforms.Resize([368,288]),
                transforms.ToTensor(),
                transforms.Normalize(mean=(0.485, 0.456, 0.406),
                                     std=(0.229, 0.224, 0.225))
            ])
            img = data_transform(original_img)
            img = torch.unsqueeze(img, dim=0).to(self.device)

            self.model.eval()
            with torch.no_grad():
                output = self.model(img)
                prediction = output.argmax(1).squeeze(0)
                prediction = prediction.cpu().numpy().astype(np.uint8)
                mask = PILImage.fromarray(prediction)
                resize = transforms.Resize([frame.shape[0], frame.shape[1]])
                mask = resize(mask)
                mask.putpalette(self.palette)

                gray = mask.convert("L")
                gray = np.array(gray)
                _, binary_mask = cv2.threshold(gray, 1, 255, cv2.THRESH_BINARY)

                contours, _ = cv2.findContours(binary_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                if contours:
                    contour = max(contours, key=cv2.contourArea)
                    left_points = []
                    right_points = []
                    for point in contour:
                        x, y = point[0]
                        if x < frame.shape[1] // 2:
                            left_points.append([x, y])
                        else:
                            right_points.append([x, y])
                    #contour_points = contour.squeeze(1)  # [N, 2]
                    #left_mask = contour_points[:, 0] < frame.shape[1] // 2
                    #left_points = contour_points[left_mask]
                    #right_points = contour_points[~left_mask]

                    left_points = np.array(left_points)
                    right_points = np.array(right_points)

                    if len(left_points) > 0:
                        [vx, vy, lx, ly] = cv2.fitLine(left_points, cv2.DIST_L2, 0, 0.01, 0.01)
                        left_slope = vy / vx
                        left_intercept = ly - (left_slope * lx)
                    else:
                        left_slope = None
                        left_intercept = None

                    if len(right_points) > 0:
                        [vx, vy, rx, ry] = cv2.fitLine(right_points, cv2.DIST_L2, 0, 0.01, 0.01)
                        right_slope = vy / vx
                        right_intercept = ry - (right_slope * rx)
                    else:
                        right_slope = None
                        right_intercept = None

                    if left_slope is not None and right_slope is not None:
                        intersection_x = (right_intercept - left_intercept) / (left_slope - right_slope)
                        intersection_y = left_slope * intersection_x + left_intercept

                        global previous_intersection_x, previous_intersection_y, alpha
                        if previous_intersection_x is not None and previous_intersection_y is not None:
                            intersection_x = alpha * previous_intersection_x + (1 - alpha) * intersection_x
                            intersection_y = alpha * previous_intersection_y + (1 - alpha) * intersection_y

                        # 更新上一帧的交点
                        previous_intersection_x = intersection_x
                        previous_intersection_y = intersection_y

                        y_bottom = frame.shape[0]
                        if left_slope is not None:
                            x_bottom_left = int((y_bottom - left_intercept) / left_slope)
                        else:
                            x_bottom_left = frame.shape[1] // 2  # 默认值
                        if right_slope is not None:
                            x_bottom_right = int((y_bottom - right_intercept) / right_slope)
                        else:
                            x_bottom_right = frame.shape[1] // 2  # 默认值

                        center_x = int((x_bottom_left + x_bottom_right) / 2)
                        center_y = frame.shape[0]

                        # 计算偏差（偏离图像中心的距离）
                        err = intersection_x - frame.shape[1] / 2

                        # 使用PID控制器来计算角速度
                        angular_z = self.pid.update(err)

                        # 设置速度和角速度，如果尚未达成行驶距离则继续行驶
                        twist = Twist()
                        if not self.distance_reached and not self.obstacle_detected:
                            twist.angular.z = -angular_z
                            twist.linear.x = self.target_speed
                        else:
                            # 如果已达到目标距离或检测到障碍物，则保持停止
                            twist = Twist()

                        with self.lock:
                            self.current_twist = twist

                        # 可选：绘制调试线条
                        cv2.line(frame, (int(intersection_x), int(intersection_y)), (x_bottom_left, y_bottom),
                                 (0, 0, 255), 2)
                        cv2.line(frame, (int(intersection_x), int(intersection_y)), (x_bottom_right, y_bottom),
                                 (0, 255, 0), 2)
                        cv2.line(frame, (int(intersection_x), int(intersection_y)), (center_x, center_y), (255, 0, 0), 2)

                # 显示处理后的当前帧图像（可用于调试）
                cv2.imshow('Processed Frame', frame)
                cv2.waitKey(1)

        except Exception as e:
            rospy.logerr(f"Error in image processing: {str(e)}")
            self.stop_robot()

    def laser_callback(self, msg):
        """
        处理激光雷达数据消息的回调函数，用于检测障碍物。
        """
        try:
            # 获取激光雷达的距离数据
            ranges = np.array(msg.ranges)
            valid_ranges = ranges[np.isfinite(ranges)]
            if valid_ranges.size > 0:
                min_distance = np.min(valid_ranges)
            else:
                min_distance = float('inf')

            with self.lock:
                if min_distance <= 0.15:
                    if not self.obstacle_detected:
                        self.obstacle_detected = True
                        rospy.loginfo(f"Obstacle detected at distance {min_distance:.2f}m! Stopping robot.")
                else:
                    if self.obstacle_detected:
                        rospy.loginfo(f"Obstacle cleared. Minimum distance: {min_distance:.2f}m.")
                    self.obstacle_detected = False
        except Exception as e:
            rospy.logerr(f"Error in laser scan processing: {str(e)}")
            self.stop_robot()

    def get_twist(self):
        with self.lock:
            return self.current_twist

    def stop_robot(self):
        with self.lock:
            self.current_twist = Twist()
        self.cmd_vel_pub.publish(self.current_twist)
        rospy.loginfo("Robot stopped.")
        # 发布完成信号，以通知状态机切换状态
        self.completion_pub.publish(Bool(data=True))
        #rospy.signal_shutdown("LineFollower completed.")

    def run(self):
        rate = rospy.Rate(10)  # 10Hz
        while not rospy.is_shutdown():
            twist_line_follower = self.get_twist()
            self.cmd_vel_pub.publish(twist_line_follower)
            rate.sleep()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    try:
        follower = LineFollower()
        follower.run()
    except rospy.ROSInterruptException:
        pass
