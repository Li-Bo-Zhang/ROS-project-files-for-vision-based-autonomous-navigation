#!/usr/bin/env python
# scout_controller_node.py
import sys
import numpy as np
import os
import rospy
from geometry_msgs.msg import Twist
import threading
import tf.transformations
import math
from sensor_msgs.msg import LaserScan, Imu
from nav_msgs.msg import Odometry
from std_msgs.msg import Bool

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

import time
import json

# PID控制器类
class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0
        self.prev_error = 0
        self.prev_time = time.time()

    def update(self, error):
        current_time = time.time()
        dt = current_time - self.prev_time
        if dt <= 0.0:
            dt = 1e-16  # 避免除以零
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt

        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)

        self.prev_error = error
        self.prev_time = current_time

        return output

# ScoutController类
class ScoutController:
    def __init__(self, action_sequence_file):
        """
        初始化 ScoutController。

        :param action_sequence_file: 包含动作序列的 JSON 文件路径。
        """
        # 初始化 ROS 节点
        rospy.init_node('scout_controller', anonymous=True)



        # 从 JSON 文件读取动作序列
        if not os.path.exists(action_sequence_file):
            rospy.logerr(f"Action sequence file {action_sequence_file} does not exist.")
            rospy.signal_shutdown("Missing action sequence file.")
            return

        with open(action_sequence_file, "r") as f:
            self.action_sequence = json.load(f)

        self.current_action_index = 0
        self.current_action = None

        # 控制参数
        self.forward_Kp = rospy.get_param("~forward_Kp", 0.8)
        self.forward_Kd = rospy.get_param("~forward_Kd", 0.1)
        self.rotate_Kp = rospy.get_param("~rotate_Kp", 1.2)
        self.target_speed = rospy.get_param("~target_speed", 0.1)
        self.min_obstacle_distance = rospy.get_param("~min_obstacle_distance", 0.2)

        # 状态变量
        self.init_angle_set = False
        self.init_angle = 0.0
        self.current_yaw = 0.0
        self.target_angle = 0.0
        self.obstacle_detected = False

        # PID控制器
        self.pid = PIDController(kp=1.0, ki=0.0, kd=0.1)

        # 当前twist和锁
        self.current_twist = Twist()
        self.lock = threading.Lock()

        # 内部状态机
        self.internal_state = "IDLE"  # 初始状态
        self.move_start_position = None
        self.turn_start_yaw = None
        
        # 初始化订阅和发布
        self.cmd_vel_pub = rospy.Publisher("/smoother_cmd_vel", Twist, queue_size=1)
        self.completion_pub = rospy.Publisher("/state_completed", Bool, queue_size=1)  # 发布完成信号
        rospy.Subscriber("/scan", LaserScan, self.laser_callback)
        rospy.Subscriber('/imu', Imu, self.imu_callback)
        rospy.Subscriber('/odom', Odometry, self.odom_callback)

    def imu_callback(self, data):
        # 持续更新当前yaw角度
        _, _, yaw = self.quaternion_to_euler(
            data.orientation.x, data.orientation.y, data.orientation.z, data.orientation.w
        )
        with self.lock:
            if not self.init_angle_set:
                self.init_angle = yaw
                self.current_yaw = self.init_angle
                self.init_angle_set = True
                rospy.loginfo(f"Initial yaw angle set to: {math.degrees(self.init_angle):.2f} degrees")
                # 开始执行第一个动作
                self.start_next_action()
            else:
                self.current_yaw = yaw
                # rospy.loginfo(f"Updated yaw angle: {math.degrees(self.current_yaw):.2f} degrees")

    def laser_callback(self, data):
        try:
            ranges = np.array(data.ranges)
            valid_ranges = ranges[np.isfinite(ranges)]
            if valid_ranges.size > 0:
                min_distance = np.min(valid_ranges)
            else:
                min_distance = float('inf')

            with self.lock:
                if min_distance < self.min_obstacle_distance:
                    if not self.obstacle_detected:
                        self.obstacle_detected = True
                        rospy.loginfo(f"Obstacle detected at distance {min_distance:.2f}m! Stopping robot.")
                else:
                    if self.obstacle_detected:
                        rospy.loginfo(f"Obstacle cleared. Minimum distance: {min_distance:.2f}m.")
                        self.obstacle_detected = False
        except Exception as e:
            rospy.logerr(f"Error in laser scan processing: {str(e)}")

    def quaternion_to_euler(self, x, y, z, w):
        quaternion = (x, y, z, w)
        return tf.transformations.euler_from_quaternion(quaternion)

    def odom_callback(self, msg):
        with self.lock:
            if self.internal_state.startswith("MOVE_FORWARD"):
                if self.move_start_position is None:
                    # 记录移动的起始位置
                    self.move_start_position = msg.pose.pose.position
                    rospy.loginfo(f"{self.internal_state} started. Target distance: {self.current_action['value']}m")
                else:
                    # 计算当前位置与起始位置的距离
                    current_position = msg.pose.pose.position
                    dx = current_position.x - self.move_start_position.x
                    dy = current_position.y - self.move_start_position.y
                    dz = current_position.z - self.move_start_position.z
                    distance = math.sqrt(dx ** 2 + dy ** 2 + dz ** 2)

                    rospy.logdebug(f"Distance traveled: {distance:.2f}m / {self.current_action['value']}m")

                    if distance >= self.current_action['value']:
                        rospy.loginfo(f"{self.internal_state} completed. Traveled {distance:.2f}m.")
                        self.current_action_index += 1  # 增加索引，指向下一个动作
                        self.start_next_action()

            elif self.internal_state.startswith("TURN"):
                # 由 get_twist 管理转向完成
                pass

    def start_next_action(self):
        if self.current_action_index >= len(self.action_sequence):
            rospy.loginfo("All actions completed. Stopping robot.")
            self.stop_robot()
            return

        self.current_action = self.action_sequence[self.current_action_index]
        action = self.current_action['action']
        value = self.current_action['value']

        rospy.loginfo(f"Starting action: {action} with value: {value}")

        if action == "MOVE_FORWARD":
            self.internal_state = f"MOVE_FORWARD_{self.current_action_index + 1}"
            self.move_start_position = None
        elif action == "TURN":
            self.internal_state = "TURN"
            self.turn_start_yaw = self.current_yaw
            # 计算目标角度，并确保在0到2pi范围内
            self.target_angle = (self.current_yaw + math.radians(value)) % (2 * math.pi)
            rospy.loginfo(f"Initiating turn. Turning {value} degrees to target yaw: {math.degrees(self.target_angle):.2f} degrees.")
        else:
            rospy.logerr(f"Unknown action: {action}")
            self.current_action_index += 1  # 跳过未知动作
            self.start_next_action()  # 递归调用以启动下一个动作

    def get_twist(self):
        with self.lock:
            if self.internal_state == "IDLE":
                return Twist()

            if self.obstacle_detected:
                return Twist()

            if self.internal_state.startswith("MOVE_FORWARD"):
                # 直线行驶
                twist = Twist()
                twist.linear.x = self.target_speed
                twist.angular.z = 0.0
                self.current_twist = twist
                return twist

            elif self.internal_state == "TURN":
                # 获取当前 yaw 角
                current_yaw = self.current_yaw

                # 计算误差
                yaw_error = (self.target_angle - current_yaw + math.pi) % (2 * math.pi) - math.pi
                rospy.logdebug(f"Yaw error: {math.degrees(yaw_error):.2f} degrees")

                # 使用 PID 控制器进行角速度调整
                angular_z = self.pid.update(yaw_error)

                # 设置速度和角速度
                twist = Twist()
                twist.linear.x = 0.0
                twist.angular.z = angular_z
                self.current_twist = twist

                # 判断是否完成转向
                if abs(yaw_error) < math.radians(1):  # 1度误差范围内认为完成
                    rospy.loginfo(f"Turn completed. Target yaw: {math.degrees(self.target_angle):.2f} degrees.")
                    self.current_action_index += 1  # 增加动作索引
                    self.start_next_action()  # 启动下一个动作
                return twist

            else:
                return Twist()  # 默认停止

    def is_completed(self):
        with self.lock:
            return self.internal_state == "COMPLETED"

    def stop_robot(self):
        #print(self.lock)
        rospy.loginfo("Attempting to acquire lock in stop_robot")
        if self.lock.acquire(blocking=False):
            try:
                rospy.loginfo("Lock acquired in stop_robot")
                self.current_twist = Twist()
                #self.internal_state = "COMPLETED"
            finally:
                self.lock.release()
                rospy.loginfo("Lock released in stop_robot")
        else:
            rospy.logwarn("Unable to acquire lock in stop_robot, skipping operation")

        self.current_twist = Twist()
        self.cmd_vel_pub.publish(self.current_twist)
        rospy.loginfo("Robot stopped.")
        self.completion_pub.publish(Bool(data=True))
        #rospy.signal_shutdown("ScoutController completed.")


    def run(self):
        rate = rospy.Rate(10)  # 10Hz
        while not rospy.is_shutdown():
            twist_scout_controller = self.get_twist()
            self.cmd_vel_pub.publish(twist_scout_controller)
            rate.sleep()

        
if __name__ == '__main__':
    try:
        # 获取/tmp目录下所有以scout_action开头且以.json结尾的文件列表
        files = [f for f in os.listdir('/home/nvidia/indoor_ws/src/robot_control/temp/') if f.startswith('scout_action') and f.endswith('.json')]
        if files:
            # 提取文件名中的序号部分（假设文件名格式固定是scout_action_序号.json这种形式）
            def get_index(file_name):
                index_str = file_name.split('_')[2].split('.')[0]
                return int(index_str)


            max_index_file = max(files, key=get_index)
            action_sequence_file = os.path.join('/home/nvidia/indoor_ws/src/robot_control/temp/', max_index_file)
        else:
            action_sequence_file = "/home/nvidia/indoor_ws/src/robot_control/temp/scout_action_1.json"

        controller = ScoutController(action_sequence_file)
        controller.run()
    except rospy.ROSInterruptException:
        pass
